import os
from Admin import Restaurant
from User import User
from details import User_Details
from datetime import date
from Exception import InvalidInputError

class Usermgmt():
    def DisplayMenu():
        data = []
        if(os.path.exists("Admindata.txt")):
                    with open ("Admindata.txt" , "r") as fp:
                        #data = fp.read()
                        for x in fp:
                            x = x.split(",")
                            data.append(x)
                        #print(data)
                    gap = " "*3
                    heading = f"{'ID':3s}{gap}{'ITEM_NAME':30s}{gap}{'PRICE':5s}{gap}{'TYPE':10s}"
                    print("="*60)
                    print(heading)
                    print("-"*60)
                    for x in data:
                        #rec = (f"{x[0]:3s}{gap}{x[1]:30s}{gap}{x[2]:5s}{gap}{x[3]:10s}")
                        print((f"{x[0]:3s}{gap}{x[1]:30s}{gap}{x[2]:5s}{gap}{x[3]:10s}"))
                    print("-"*60)
                  
            
    

                                
                                
    def Order_Items(id,qty):
         with open ("Admindata.txt","r") as fp:
                    for e in fp:
                        try:
                            e.index(str(id),0,4)

                        except ValueError:
                            pass
                            
                        
                        else:
                            e = e.split(",")
                            e.insert(3,str(qty))
                            #print(e)
                            #e[0] = e[0]
                            #e[1] = e[1]
                            #e[2] = e[2]
                            #e[3] = e[3]
                            e =  User(e[0],e[1],e[2],e[3],e[4]) 
                            with open("User.txt","a") as fp:
                                    fp.write(str(e))
                                    #fp.write("\n")


    def Search_Menu_bytype(type):
        if(os.path.exists("Admindata.txt")):
            with open("Admindata.txt","r") as fp:
                for e in fp:
                    if(type in e):
                        #print("Record found")
                        print(e)
                        #break

                #else:
                    #print("Record Not Found")
        else:
            print("File not found")


    def Display_Order():
        order = []
        if(os.path.exists("User.txt")):
                with open ("User.txt","r") as fp:
                    
                    for x in fp:
                        x = x.split(",")
                        order.append(x)
                    
                gap = " "*3
                heading = f"{'ID':3s}{gap}{'ITEM_NAME':30s}{gap}{'PRICE':5s}{gap}{'QTY':3s}{gap}{'TYPE':10s}"
                #print("-"*66)
                print(heading)
                print("-"*66)
                for x in order:
                    rec = (f"{x[0]:3s}{gap}{x[1]:30s}{gap}{x[2]:5s}{gap}{x[3]:3s}{gap}{x[4]:10s}")
                    print(rec)
                #print("-"*66)
                

    def UpdateItembyId(id):
        if(os.path.exists("User.txt")):
                isfound = False
                Update_data = []
                with open ("User.txt","r") as fp:
                    for e in fp:
                        try:
                            e.index(str(id),0,4)

                        except ValueError:
                            pass
                            
                        
                        else:
                            e = e.split(",")
                            while 1:
                                try:
                                    ans = input("Do u want to change id(Yes/No): ")
                                    if(ans == "Yes" or ans == "No"):
                                        ans
                                        break
                                    else:
                                        raise InvalidInputError
                                except InvalidInputError:
                                        print("Invalid Input")
                            #ans = input("Do u want to change id(Yes/No): ")
                            if(ans == "Yes"):
                                while 1:
                                    try:
                                        new_id = int(input("Enter new id: "))
                                    except ValueError:
                                        print("Please Enter Numbers Only!")
                                    else:
                                        new_id
                                        break        
                                #new_id = int(input("Enter new id: "))
                                e[0] = str(new_id)


                            while 1:
                                try:
                                    ans = input("Do u want to change Name(Yes/No): ")
                                    if(ans == "Yes" or ans == "No"):
                                        ans
                                        break
                                    else:
                                        raise InvalidInputError
                                except InvalidInputError:
                                        print("Invalid Input")
                            #ans = input("Do u want to change Name(Yes/No): ")
                            if(ans == "Yes"):
                                while 1:
                                    try:
                                        new_name = input("Enter the name: ")
                                                
                                        if(new_name != '' and all(chr.isalpha() or chr.isspace() or chr.isdigit() or len(chr) != 0 for chr in itmname)):
                                            new_name
                                            break
                                        else:
                                            raise TypeError
                                    except TypeError:
                                                    print("Please Enter valid input Only!")
                                
                                #new_name = input("Enter the name: ")
                                e[1] = new_name

                            while 1:
                                try:
                                    ans = input("Do u want to change price(Yes/No): ")
                                    if(ans == "Yes" or ans == "No"):
                                        ans
                                        break
                                    else:
                                        raise InvalidInputError
                                except InvalidInputError:
                                        print("Invalid Input")    
                            #ans = input("Do u want to change price(Yes/No): ")
                            if(ans == "Yes"):
                                while 1:
                                    try:
                                        new_Price = int(input("Enter Price: "))
                                    except ValueError:
                                        print("Please Enter Numbers Only!")
                                    else:
                                        new_Price
                                        break        
                                #new_Price = int(input("Enter Price: "))
                                e[2] = str(new_Price)

                            while 1:
                                try:
                                    ans = input("Do u want to change Quantity(Yes/No): ")
                                    if(ans == "Yes" or ans == "No"):
                                        ans
                                        break
                                    else:
                                        raise InvalidInputError
                                except InvalidInputError:
                                        print("Invalid Input")    
                            #ans = input("Do u want to change Quantity(Yes/No): ")
                            if(ans == "Yes"):
                                while 1:
                                    try:
                                        new_Qty = int(input("Enter Quantity: "))
                                    except ValueError:
                                        print("Please Enter Numbers Only!")
                                    else:
                                        new_Qty 
                                        break        
                                #new_Qty = int(input("Enter Quantity: "))
                                e[3] = str(new_Qty)

                            while 1:
                                try:
                                    ans = input("Do u want to change Type(Yes/No): ")
                                    if(ans == "Yes" or ans == "No"):
                                        ans
                                        break
                                    else:
                                        raise InvalidInputError
                                except InvalidInputError:
                                    print("Invalid Input")    
                            
                            if(ans == "Yes"):
                                while 1:
                                        try:
                                            new_Type = input("Enter type(Veg/Non-Veg): ")
                                            if (type == "Veg" or type == "Non-Veg" ):
                                                    new_Type
                                                    break
                                            else:
                                                    raise TypeError
                                        except TypeError:
                                                print("Please Enter Valid Input!")
                                #new_Type = input("Enter type(Veg/Non-Veg): ")
                                e[4] = (new_Type)
                            
                            e = ",".join(e)
                            isfound = True
                            
                            
                        finally:
                            Update_data.append(e)    
                if(isfound == True):
                    with open("User.txt","w") as fp:
                        for e in Update_data:
                            fp.write(e)
                else:
                    print("record not found")

        else:
            print("file not found")

    def DeleteItembyId(id):
        if(os.path.exists("User.txt")):
            isfound = False
            Deldata = []
            with open ("User.txt","r") as fp:
                for e in fp:
                    try:
                        e.index(str(id),0,4)

                    except ValueError:
                        Deldata .append(e)

                    else:
                        isfound = True 

            if(isfound == True):
                with open ("User.txt","w") as fp:
                    for e in Deldata :
                        fp.write(e)

            else:
                print("record not found")

        else:
            print("file not found")

    def GenerateBill():
        
        
        if(os.path.exists("User.txt")):
            sum = 0
            
            with open ("User.txt","r") as fp:
                    
                    for x in fp:
                        x = x.split(",")
                        x[2] = (eval(x[2]))
                        x[3] = (eval(x[3]))
                        sum = sum + (x[2]*x[3])
        # if(os.path.exists("User.txt")):
        #         today = date.today()
        #         with open("user_details.txt","r") as fp:
        #             for i in fp:
        #                 #print(i)
        #                 i = i.split(",")
        #                 #print(i)
        #                 #print(i[1])
        #             print("="*66)
        #             print("            WELCOME TO CODER'Z ZONE RESTAURANT")
        #             print()
        #             print("Userid: ", i[0],end=" "*25)
        #             print("Name: ",i[1])
        #             print("Date: ",today,end=" "*21)
        #             print("Mobile No: ",i[2])
                    
                    print("="*66)
        gap = " "*13
        gap1 = " "
        heading = f"{'TOTAL AMT TO PAY(Rupees):':10s}{gap}{sum:5d}"
        #print("="*66)
        print(heading)
        print("-"*66)                
        print()
        Regards = f"{gap1}{'!!!!THANK YOU SIR FOR GIVING US CHANCE TO SERVE OUR SERVICE!!!!':56s}"
        print(Regards)
        print()
        print()
        os.remove("User.txt")

    def Add_user_details(e):
        with open ("User_details.txt","a") as fp:
            fp.write(str(e))
            fp.write("\n") 

    def Bill_Format():
            if(os.path.exists("user_details.txt")):
                today = date.today()
                with open("user_details.txt","r") as fp:
                    for i in fp:
                         #print(i)
                        i = i.split(",")
                        #print(i)
                         #print(i[1])
                    print("="*66)
                    print("            WELCOME TO CODER'Z ZONE RESTAURANT")
                    print()
                    print("Userid: ", i[0],end=" "*25)
                    print("Name: ",i[1])
                    print("Date: ",today,end=" "*21)
                    print("Mobile No: ",i[2])
                    
                    print("="*66)    
            else:
                print("File Not Found")
