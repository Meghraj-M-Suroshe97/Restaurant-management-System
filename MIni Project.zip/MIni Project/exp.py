# 

id = 101        
with open ("Admindata.txt","r") as fp:
    for e in fp:
        if (e.find(str(id),0,4)) == 0:
            print("record found")
            break
    
                                                                                                                