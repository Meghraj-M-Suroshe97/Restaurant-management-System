class User:

    def __init__(self,id,itmname,price,qty,type):
        self.Id = id
        self.item_name = itmname
        self.Price = price
        self.Qty = qty
        self.Type = type

    def __str__(self):
        return str(self.Id)+","+self.item_name+","+str(self.Price)+","+str(self.Qty)+","+(self.Type)

    def User_details(self,userid,name):
        self.UserId = userid
        self.UserName = name


#e = User(101,"biryani",300,2,"non-veg")
#print(e)