#data = [["hansika","101","dinesh"]]
#data1 = [["hansika","100","dinesh"]]
#res = [(eval(data[0][1]))+(eval(data1[0][1])) ]
#print((res))
import os
from Admin import Restaurant
from User import User
from datetime import date
#order = []
'''def Display_Order():
      
      if(os.path.exists("User.txt")):
            with open ("User.txt" , "r") as fp:
                    print(fp)
                    data = fp.read()
                    print(data)
                
                #for x in fp:
                    #print(x)
                    #x = x.split(",")
                    #print(x)
                    #order.append(x)
                
            #gap = " "*3
            #heading = f"{'ID':3s}{gap}{'ITEM_NAME':30s}{gap}{'PRICE':5s}{gap}{QTY}{gap}{'TYPE':10s}"
            #print("="*66)
            #print(heading)
            #print("-"*66)
            #for x in order:
                #rec = (f"{x[0]:3s}{gap}{x[1]:30s}{gap}{x[2]:5s}{gap}{x[3]:3s}{gap}{x[4]:10s}")
                #print(rec)
            #print("-"*66)'''

'''def updatebyId(id):
        if(os.path.exists("User.txt")):
            isfound = False
            Update_data = []
            with open ("User.txt","r") as fp:
                for e in fp:
                    try:
                        e.index(str(id),0,4)

                    except ValueError:
                        pass
                        
                    
                    else:
                        e = e.split(",")
                        ans = input("Do u want to change id(Yes/No): ")
                        if(ans == "Yes"):
                            new_id = int(input("Enter new id: "))
                            e[0] = str(new_id)
                        ans = input("Do u want to change Name(Yes/No): ")
                        if(ans == "Yes"):
                            new_name = input("Enter the name: ")
                            e[1] = new_name
                        ans = input("Do u want to change price(Yes/No): ")
                        if(ans == "Yes"):
                            new_Price = int(input("Enter Price: "))
                            e[2] = str(new_Price)
                        ans = input("Do u want to change Type(Yes/No): ")
                        if(ans == "Yes"):
                            new_Type = input("Enter type(Veg/Non-Veg): ")
                            e[3] = (new_Type)
                           
                        e = ",".join(e)
                        isfound = True
                        
                        
                    finally:
                        Update_data.append(e)    
            if(isfound == True):
                with open("User.txt","w") as fp:
                    for e in Update_data:
                        fp.write(e)
            else:
                print("record not found")

        else:
            print("file not found")
id = int(input("enter id: "))
updatebyId(id)'''


'''sum = 0         
#Bill = []
with open ("User.txt","r") as fp:
    #data = fp.read()
    for x in fp:
        x = x.split(",")
        x[2] = (eval(x[2]))
        sum = sum + x[2]   
        #Bill.append(x)
    #print(Bill)

                     
    print(sum)                
           
gap = "   "*9
gap1 = " "*39
heading = f"{'TOTAL AMT TO PAY:':10s}{gap}{sum:5d}"
print("="*66)
print(heading)
print("-"*66)

#rec = (f"{gap}{sum}")
#print(rec)
#rint("-"*66)      
           
'''
'''userlist = []
import random
Num = random.randint(1111,9999)
print("Genrted ID: ",Num)
userid = int(input("enter above genrated id: "))
name = input("Enter your in (Name-Middle Name-Surname): ")
userlist.append(str(userid))
userlist.append(name)
#print(userlist)
userlist = ",".join
print(userlist)'''
if(os.path.exists("user_details.txt")):
        today = date.today()
        with open("user_details.txt","r") as fp:
            for i in fp:
                #print(i)
                i = i.split(",")
                #print(i)
                #print(i[1])
            print("="*66)
            print("            WELCOME TO CODER'Z ZONE RESTAURANT")
            print()
            print("Userid: ", i[0],end=" "*25)
            print("Name: ",i[1])
            print("Date: ",today,end=" "*21)
            print("Mobile No: ",i[2])
            
            print("="*66)

if(os.path.exists("User.txt")):
    sum = 0
    
    with open ("User.txt","r") as fp:
            
            for x in fp:
                x = x.split(",")
                x[2] = (eval(x[2]))
                x[3] = (eval(x[3]))
                sum = sum + (x[2]*x[3])

gap = " "*13
gap1 = " "
heading = f"{'TOTAL AMT TO PAY(Rupees):':10s}{gap}{sum:5d}"
#print("="*66)
print(heading)
print("-"*66)                
print()
Regards = f"{gap1}{'!!!!THANK YOU SIR FOR GIVING US CHANCE TO SERVE OUR SERVICE!!!!':56s}"
print(Regards)
print()
print()