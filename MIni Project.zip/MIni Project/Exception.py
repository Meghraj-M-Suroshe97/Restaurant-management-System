class InvalidInputError(Exception):
    pass