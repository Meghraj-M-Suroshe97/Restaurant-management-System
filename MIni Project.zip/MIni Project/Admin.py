class Restaurant:
    def __init__(self,id,itmname,price,type):
        self.Id = id
        self.item_name = itmname
        self.Price = price
        self.Type = type

    def __str__(self):
        return str(self.Id)+","+self.item_name+","+str(self.Price)+","+(self.Type)
           

#e = Restaurant(101,"biryani",300,"non-veg")
#print(e)