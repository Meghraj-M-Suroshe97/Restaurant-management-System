import os
from adminmgmt import Adminmgmt
#from Admin import Restaurant
from Usermgmt import Usermgmt
from User import User
from details import User_Details
from datetime import date
from colorama import Fore
print(Fore.CYAN + "-"*60)
print(Fore.BLUE + "         WE ARE HAPPY TO HAVE AS CUSTOMER")
print("-"*60)
if(__name__ == "__main__"):
    print("Plz Carry two step Sign_in As customer")
                            
    import random
    Num = random.randint(1111,9999)
    print("Genrted ID: ",Num)
    userid = int(input("enter above genrated id: "))
    name = input("Enter your in (Name-Middle Name-Surname): ")
    phone_no = int(input("enter Your 10 digit Mobile No(eg:9823******): "))
    e = User_Details(userid,name,phone_no)
    Usermgmt.Add_user_details(e)
    print()
    

    choice = 0
    while(choice != 7):
        print("-"*66)
        print("1. DisplayMenu")
        print("2. Order_Items")
        print("3. Display_Orders")
        print("4. Update_Order")
        print("5. DeleteItembyId")
        print("6. GenerateBill")
        print("7. Exit")
        print("-"*66)
        choice = int(input("Enter your choice: "))
        print()
        if(choice == 1):
            Usermgmt.DisplayMenu()
        
        elif(choice == 2):
                Usermgmt.DisplayMenu()
                while 1:
                        try:
                                id = int(input("Enter Id Of Item: "))
                        except ValueError:
                                print("Please Enter Numbers Only!")
                        else:
                                id
                                break        
                #id = int(input("Enter Id Of Item: "))
                while 1:
                        try:
                                qty =int(input("Enter Quantity of item in (1,2,3...)as per your requirement: "))
                        except ValueError:
                                print("Please Enter Numbers Only!")
                        else:
                                qty
                                break        
                #qty =int(input("Enter Quantity of item in (1,2,3...)as per your requirement: "))
                Usermgmt.Order_Items(id, qty)


        elif(choice == 3):
            Usermgmt.Display_Order()

        elif(choice == 4):
                Usermgmt.Display_Order()
                while 1:
                        try:
                                id = int(input("Enter Id Of Item to update: "))
                        except ValueError:
                                print("Please Enter Numbers Only!")
                        else:
                                id
                                break        
                #id = int(input("Enter Id Of Item to update: "))
                Usermgmt.UpdateItembyId(id)

        elif(choice == 5):
                Usermgmt.Display_Order()
                while 1:
                        try:
                                id = int(input("Enter Id Of Item to Delete: "))
                        except ValueError:
                                print("Please Enter Numbers Only!")
                        else:
                                id
                                break        
                #id = int(input("Enter Id Of Item to Delete: "))
                Usermgmt.DeleteItembyId(id) 

        elif(choice == 6):
            Usermgmt.Bill_Format()
            Usermgmt.Display_Order()
            Usermgmt.GenerateBill()
            choice = 7
            
                        
                        