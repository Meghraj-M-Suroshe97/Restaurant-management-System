import os
from Admin  import Restaurant
from Exception import InvalidInputError
class Adminmgmt:
    def AddMenu(e):
        
        with open ("Admindata.txt","a") as fp:
            fp.write(str(e))
            fp.write("\n")

    
    def DisplayMenu():
        data = []
        if(os.path.exists("Admindata.txt")):
                    with open ("Admindata.txt" , "r") as fp:
                        #data = fp.read()
                        for x in fp:
                            x = x.split(",")
                            data.append(x)
                        #print(data)
                    gap = " "*3
                    heading = f"{'ID':3s}{gap}{'ITEM_NAME':30s}{gap}{'PRICE':5s}{gap}{'TYPE':10s}"
                    print("="*60)
                    print(heading)
                    print("-"*60)
                    for x in data:
                        #rec = (f"{x[0]:3s}{gap}{x[1]:30s}{gap}{x[2]:5s}{gap}{x[3]:10s}")
                        print((f"{x[0]:3s}{gap}{x[1]:30s}{gap}{x[2]:5s}{gap}{x[3]:10s}"))
                    print("-"*60)
                  
            
    
    
    def SearchbyId(id):
        if(os.path.exists("Admindata.txt")):
            with open ("Admindata.txt","r") as fp:
                for e in fp:
                    try:
                        e.index(str(id),0,4)
                    except ValueError:
                        pass
                    else:
                        print("Record found")
                        print(e)
                        break

                else:
                    print("Record Not Found")

        else:
            print("File not found")
   
    def Searchbytype(type):
        if(os.path.exists("Admindata.txt")):
            with open("Admindata.txt","r") as fp:
                for e in fp:
                    if(type in e):
                        #print("Record found")
                        print(e)
                        #break

                #else:
                    #print("Record Not Found")
        else:
            print("File not found")
    
    def updatebyId(id):
        if(os.path.exists("Admindata.txt")):
            isfound = False
            Restdata = []
            with open ("Admindata.txt","r") as fp:
                for e in fp:
                    try:
                        e.index(str(id),0,4)

                    except ValueError:
                        pass
                        
                    
                    else:
                        e = e.split(",")
                        while 1:
                            try:
                                ans = input("Do u want to change id(Yes/No): ")
                                if(ans == "Yes" or ans == "No"):
                                    ans
                                    break
                                else:
                                    raise InvalidInputError
                            except InvalidInputError:
                                print("Invalid Input")
                        if(ans == "Yes"):
                            while 1:
                                    try:
                                            new_id = int(input("Enter new id: "))
                                    except ValueError:
                                            print("Please Enter Numbers Only!")
                                    else:
                                            new_id
                                            break        
                        #if(ans == "Yes"):
                            new_id = int(input("Enter new id: "))
                            e[0] = str(new_id)
                        
                        while 1:
                            try:
                                ans = input("Do u want to change Name(Yes/No): ")
                                if(ans == "Yes" or ans == "No"):
                                    ans
                                    break
                                else:
                                    raise InvalidInputError
                            except InvalidInputError:
                                print("Invalid Input")
                                
                        if(ans == "Yes"):
                            while 1:
                                    try:
                                        new_name = input("Enter the name: ")
                                                
                                        if(new_name != '' and all(chr.isalpha() or chr.isspace() or chr.isdigit() or len(chr) != 0 for chr in itmname)):
                                            new_name
                                            break
                                        else:
                                            raise TypeError
                                    except TypeError:
                                                    print("Please Enter valid input Only!")

                            #new_name = input("Enter the name: ")
                            e[1] = new_name
                        
                        while 1:
                            try:
                                ans = input("Do u want to change price(Yes/No): ")
                                if(ans == "Yes" or ans == "No"):
                                    ans
                                    break
                                else:
                                    raise InvalidInputError
                            except InvalidInputError:
                                print("Invalid Input")

                        if(ans == "Yes"):
                            while 1:
                                    try:
                                        new_Price = int(input("Enter new Price: "))
                                    except ValueError:
                                        print("Please Enter Numbers Only!")
                                    else:
                                        new_Price
                                        break        
                            #new_Price = int(input("Enter Price: "))
                            e[2] = str(new_Price)

                        while 1:
                            try:
                                ans = input("Do u want to change Type(Yes/No): ")
                                if(ans == "Yes" or ans == "No"):
                                    ans
                                    break
                                else:
                                    raise InvalidInputError
                            except InvalidInputError:
                                print("Invalid Input")    
                        
                        if(ans == "Yes"):
                            while 1:
                                    try:
                                        new_Type = input("Enter type(Veg/Non-Veg): ")
                                        if (type == "Veg" or type == "Non-Veg" ):
                                                new_Type
                                                break
                                        else:
                                                raise TypeError
                                    except TypeError:
                                            print("Please Enter Valid Input!")
                            #new_Type = input("Enter type(Veg/Non-Veg): ")
                            e[3] = (new_Type)
                           
                        e = ",".join(e)
                        isfound = True
                        
                        
                    finally:
                        Restdata .append(e)    
            if(isfound == True):
                with open("Admindata.txt","w") as fp:
                    for e in Restdata :
                        fp.write(e)
            else:
                print("record not found")

        else:
            print("file not found")
    
    def DeletebyId(id):
        if(os.path.exists("Admindata.txt")):
            isfound = False
            Restdata = []
            with open ("Admindata.txt","r") as fp:
                for e in fp:
                    try:
                        e.index(str(id),0,4)

                    except ValueError:
                        Restdata .append(e)

                    else:
                        isfound = True 

            if(isfound == True):
                with open ("Admindata.txt","w") as fp:
                    for e in Restdata :
                        fp.write(e)

            else:
                print("record not found")

        else:
            print("file not found")