import os
from adminmgmt import Adminmgmt
from Admin import Restaurant
from Exception import InvalidInputError
import re
import colorama
from colorama import Fore
print(Fore.CYAN + "="*50)
print(Fore.BLUE + "       WELCOME TO CODER'Z ZONE RESTAURANT")
print("="*50)
if(__name__ == "__main__"):
        
        while 1:
        
                #Admin = input("R u Admin (Yes/No): ")
                #if(Admin == "Yes" or Admin == "No"):
                
                try:
                        Admin = input("R u Admin (Yes/No): ")
                        if(Admin == "Yes" or Admin == "No"):
                                Admin
                                #break
                        else:
                                raise InvalidInputError
                except InvalidInputError:
                        print("Invalid Input")
                
                # if(Admin == "Yes"):
                #         while 1:
                #                 try:
                #                         #Admin = input("R u Admin (Yes/No): ")
                #                         if( Admin == "Yes" ):
                #                                 Admin
                #                                 break
                #                         else:
                #                                 raise InvalidInputError
                #                 except InvalidInputError:
                #                         print("Invalid Input")
                
                if(Admin == "Yes"):
                        Adminid = input("enter Admin id  = ")
                        password = input("enter the password = ")

                        if( Adminid == "Admin" and password == "Admin"):
                                import random
                                captcha = random.randint(1000, 9999)
                                                
                                print ("captcha code = ",captcha)
                                                
                                A = int(input("enter the captcha code = "))
                                                
                                if (captcha == A):
                                        print("login successful")
                                
                                        Ad=Adminmgmt()

                                        choice = 0
                                        while(choice != 10):
                                                print("1. AddMenu")
                                                print("2. DisplayMenu")
                                                print("3. SerachbyId")
                                                print("4. Searchbytype(Veg/Non-Veg)")
                                                print("5. updatebyId")
                                                print("6. DeletebyId")
                                                print("10. Exit")
                                                print()
                                                while 1:
                                                        try:
                                                                choice = int(input("Enter choice: "))
                                                        except ValueError:
                                                                print("Please Enter Numbers Only!")
                                                        else:
                                                                choice
                                                                break        
                                                

                                                if(choice == 1):
                                                        while 1:
                                                                try:
                                                                        id = int(input("Enter Id Of Item: "))
                                                                except ValueError:
                                                                        print("Please Enter Numbers Only!")
                                                                else:
                                                                        id
                                                                        break        
                                                        
                                                        itmname = input("Enter Name of Item: ")
                                                        while 1:
                                                                try:
                                                                        itmname = input("Enter Name of Item: ")
                                                                                
                                                                        if(itmname != '' and all(chr.isalpha() or chr.isspace() or chr.isdigit() or len(chr) != 0 for chr in itmname)):
                                                                                itmname
                                                                                break
                                                                        else:
                                                                               raise TypeError
                                                                except TypeError:
                                                                          print("Please Enter valid input Only!")

                                                        while 1:
                                                                try:
                                                                        price = int(input("Enter The Price Of Item: "))
                                                                except ValueError:
                                                                        print("Please Enter Numbers Only!")
                                                                else:
                                                                        price
                                                                        break        

                                                        #type = input("Enter type(Veg/Non-Veg): ")       
                                                        while 1:
                                                                try:
                                                                        type = input("Enter Type of Item(Veg/Non-veg): ")
                                                                        if (type == "Veg" or type == "Non-Veg" ):
                                                                                type
                                                                                break
                                                                        else:
                                                                                raise TypeError
                                                                except TypeError:
                                                                        print("Please Enter Valid Input!")
                                                        e = Restaurant(id,itmname,price,type)
                                                        Adminmgmt.AddMenu(e)
                                                
                                                elif(choice == 2):
                                                        Adminmgmt.DisplayMenu()

                                                elif(choice == 3):
                                                        while 1:
                                                                try:
                                                                        id = int(input("Enter Id Of Item: "))
                                                                except ValueError:
                                                                        print("Please Enter Numbers Only!")
                                                                else:
                                                                        id
                                                                        break        
                                                        
                                                        Adminmgmt.SearchbyId(id)

                                                elif(choice == 4):
                                                        #type = input("Enter type of item Veg/Non-Veg: ")
                                                        while 1:
                                                                try:
                                                                        type = input("Enter Type of Item(Veg/Non-veg): ")
                                                                        if (type == "Veg" or type == "Non-Veg" ):
                                                                                type
                                                                                break
                                                                        else:
                                                                                raise TypeError
                                                                except TypeError:
                                                                        print("Please Enter Valid Input!")
                                                        Adminmgmt.Searchbytype(type)
                                                                                
                                                elif(choice == 5):
                                                        while 1:
                                                                try:
                                                                        id = int(input("Enter Id Of Item: "))
                                                                except ValueError:
                                                                        print("Please Enter Numbers Only!")
                                                                else:
                                                                        id
                                                                        break        
                                                        Adminmgmt.updatebyId(id)
                                                                                
                                                elif(choice == 6):
                                                        while 1:
                                                                try:
                                                                        id = int(input("Enter Id Of Item: "))
                                                                except ValueError:
                                                                        print("Please Enter Numbers Only!")
                                                                else:
                                                                        id
                                                                        break        
                                                        Adminmgmt.DeletebyId(id)
                                                                        
                                        
                                        
                                else:
                                        print("wrong captcha entered")
                                                        

                        else:
                                print("incorrect userid or password")
                elif(Admin == "No"):
                        
                        print("Welcome To User")                                
                                        