class User_Details():
    def __init__(self, userid,name,phone_no):
        self.userid = userid
        self.name = name
        self.Phone_No = phone_no
    
    def __str__(self):
        sep = ","
        return f"{self.userid}{sep}{self.name}{sep}{self.Phone_No}"
        