from adminmgmt import Adminmgmt
from Admin import Restaurant
from Exception import InvalidInputError
import re
import colorama
from colorama import Fore
print(Fore.CYAN + "="*60)
print(Fore.BLUE + "       # WELCOME TO CODER'Z ZONE RESTAURANT #")
print("="*60)
if(__name__ == "__main__"):
        
        while 1:
        
                #Admin = input("R u Admin (Yes/No): ")
                #if(Admin == "Yes" or Admin == "No"):
                
                try:
                        print("if are Admin : Type(Yes)")
                        print("if are User : Type(No)")
                        print()
                        Admin = input("R u Admin (Yes/No): ")
                        if(Admin == "Yes" or Admin == "No"):
                                Admin
                                #break
                        else:
                                raise InvalidInputError
                except InvalidInputError:
                        print("Invalid Input")
                
                # if(Admin == "Yes"):
                #         while 1:
                #                 try:
                #                         #Admin = input("R u Admin (Yes/No): ")
                #                         if( Admin == "Yes" ):
                #                                 Admin
                #                                 break
                #                         else:
                #                                 raise InvalidInputError
                #                 except InvalidInputError:
                #                         print("Invalid Input")
                
                if(Admin == "Yes"):
                        Adminid = input("enter Admin id  = ")
                        password = input("enter the password = ")

                        if( Adminid == "Admin" and password == "Admin"):
                                import random
                                captcha = random.randint(1000, 9999)
                                                
                                print ("captcha code = ",captcha)
                                while 1:
                                        try:
                                                A = int(input("enter the captcha code = "))
                                        except ValueError:
                                                print("Please enter correct captcha")
                                        else:
                                                A
                                                break        
                                                
                                # A = int(input("enter the captcha code = "))
                                                
                                if (captcha == A):
                                        print("login successful")
                                
                                        Ad=Adminmgmt()

                                        choice = 0
                                        while(choice != 10):
                                                print("1. AddMenu")
                                                print("2. DisplayMenu")
                                                print("3. SerachbyId")
                                                print("4. Searchbytype(Veg/Non-Veg)")
                                                print("5. updatebyId")
                                                print("6. DeletebyId")
                                                print("10. Exit")
                                                print()
                                                while 1:
                                                        try:
                                                                choice = int(input("Enter choice: "))
                                                        except ValueError:
                                                                print("Please Enter Numbers Only!")
                                                        else:
                                                                choice
                                                                break        
                                                

                                                if(choice == 1):
                                                        while 1:
                                                                try:
                                                                        id = int(input("Enter Id Of Item: "))
                                                                        if(len(str(id)) == 3):
                                                                                id
        
                                                                        else:
                                                                                raise ValueError
                                                                except ValueError:
                                                                        print("Please Enter Numbers and Of 3 digit!")
                                                                else:
                                                                        id
                                                                        break        
                                                        
                                                        #itmname = input("Enter Name of Item: ")
                                                        while 1:
                                                                try:
                                                                        itmname = input("Enter Name of Item: ")
                                                                                
                                                                        if(itmname != '' and all(chr.isalpha() or chr.isspace() or chr.isdigit() or len(chr) != 0 for chr in itmname)):
                                                                                itmname
                                                                                break
                                                                        else:
                                                                                raise TypeError
                                                                except TypeError:
                                                                                print("Please Enter valid input Only!")

                                                        while 1:
                                                                try:
                                                                        price = int(input("Enter The Price Of Item: "))
                                                                except ValueError:
                                                                        print("Please Enter Numbers Only!")
                                                                else:
                                                                        price
                                                                        break        

                                                        #type = input("Enter type(Veg/Non-Veg): ")       
                                                        while 1:
                                                                try:
                                                                        type = input("Enter Type of Item((*Veg)/(#Non-veg)): ")
                                                                        if (type == "*Veg" or type == "#Non-Veg" ):
                                                                                type
                                                                                break
                                                                        else:
                                                                                raise TypeError
                                                                except TypeError:
                                                                        print("Please Enter Valid Input!")
                                                        e = Restaurant(id,itmname,price,type)
                                                        Adminmgmt.AddMenu(e)
                                                
                                                elif(choice == 2):
                                                        Adminmgmt.DisplayMenu()

                                                elif(choice == 3):
                                                        while 1:
                                                                try:
                                                                        id = int(input("Enter Id Of Item: "))
                                                                        if(len(str(id)) == 3):
                                                                                id
                                                                        else:
                                                                                raise ValueError

                                                                except ValueError:
                                                                        print("Please Enter Numbers and Of 3 digit!")
                                                                else:
                                                                        id
                                                                        break        
                                                        
                                                        Adminmgmt.SearchbyId(id)

                                                elif(choice == 4):
                                                        #type = input("Enter type of item Veg/Non-Veg: ")
                                                        while 1:
                                                                try:
                                                                        type = input("Enter Type of Item(['*': for Veg]/['#': Non-veg]): ")
                                                                        if (type == "*" or type == "#" ):
                                                                                type
                                                                                break
                                                                        else:
                                                                                raise TypeError
                                                                except TypeError:
                                                                        print("Please Enter Valid Input!")
                                                        Adminmgmt.Searchbytype(type)
                                                                                
                                                elif(choice == 5):
                                                        while 1:
                                                                try:
                                                                        id = int(input("Enter Id Of Item: "))
                                                                        if(len(str(id)) == 3):
                                                                                id
                                                                        else:
                                                                                raise ValueError
                                                                except ValueError:
                                                                       print("Please Enter Numbers and Of 3 digit!")
                                                                else:
                                                                        id
                                                                        break        
                                                        Adminmgmt.updatebyId(id)
                                                                                
                                                elif(choice == 6):
                                                        while 1:
                                                                try:
                                                                        id = int(input("Enter Id Of Item: "))
                                                                        if(len(str(id)) == 3):
                                                                                id
                                                                        else:
                                                                                raise ValueError
                                                                except ValueError:
                                                                       print("Please Enter Numbers and Of 3 digit!")
                                                                
                                                                else:
                                                                        id
                                                                        break        
                                                        Adminmgmt.DeletebyId(id)
                                                                        
                                        
                                        
                                else:
                                        print("wrong captcha entered")
                                                        

                        else:
                                print("incorrect userid or password")
                
                
                elif(Admin == "No"):
                        
                        import os
                        from adminmgmt import Adminmgmt
                        #from Admin import Restaurant
                        from Usermgmt import Usermgmt
                        from User import User
                        from details import User_Details
                        from datetime import date
                        from colorama import Fore
                        print(Fore.CYAN + "-"*60)
                        print(Fore.BLUE + "         WE ARE HAPPY TO HAVE AS CUSTOMER")
                        print("-"*60)
                        if(__name__ == "__main__"):
                            print("Plz Carry two step Sign_in As customer")
                            
                            import random
                            Num = random.randint(1111,9999)
                            print("Genrted ID: ",Num)
                            while 1:
                                        try:
                                                userid = int(input("enter above genrated id: "))
                                                if(len(str(userid )) == 4):
                                                        userid
                                                else:
                                                        raise ValueError
                                        except ValueError:
                                                print("Please Enter Above genrated Id and Of 4 digit!")
                                        else:
                                                userid
                                                break        
                        #     userid = int(input("enter above genrated id: "))
                            while 1:
                                        try:
                                                name = input("Enter your in (FirstName MiddleName LastName): ")
                                                        
                                                if( name != '' and all(chr.isalpha() or chr.isspace() or len(chr) != 0 for chr in name)):
                                                        name
                                                        break
                                                else:
                                                        raise TypeError
                                        except TypeError:
                                                        print("Please Enter valid input Only!")
                        #     name = input("Enter your in (Name Middle Name Surname): ")
                            while 1:
                                        try:
                                                phone_no = int(input("enter Your 10 digit Mobile No(eg:9823******): "))
                                                if(len(str(phone_no )) == 10):
                                                        phone_no
                                                else:
                                                        raise ValueError
                                        except ValueError:
                                                print("Please Enter Above genrated Id and Of 4 digit!")
                                        else:
                                                phone_no
                                                break        
                        #     phone_no = int(input("enter Your 10 digit Mobile No(eg:9823******): "))
                            e = User_Details(userid,name,phone_no)
                            Usermgmt.Add_user_details(e)
                            print()
                            
                            
                            choice = 0
                            while(choice != 8):
                                print("-"*66)
                                print("1. DisplayMenu")
                                print("7. Search_Menu_bytype(Veg/Non-Veg)")
                                print("2. Order_Items")
                                print("3. Display_Orders")
                                print("4. Update_Order")
                                print("5. DeleteItembyId")
                                print("6. GenerateBill")
                                print("8. Exit")
                                print("-"*66)
                                choice = int(input("Enter your choice: "))
                                print()
                                if(choice == 1):
                                    Usermgmt.DisplayMenu()
                                
                                elif(choice == 2):
                                        Usermgmt.DisplayMenu()
                                        while 1:
                                                try:
                                                        id = int(input("Enter Id Of Item: "))
                                                        if(len(str(id)) == 3):
                                                                id
                                                        else:
                                                                raise ValueError
                                                except ValueError:
                                                        print("Please Enter Numbers and Of 3 digit!")
                                                else:
                                                        id
                                                        break        
                                        #id = int(input("Enter Id Of Item: "))
                                        while 1:
                                                try:
                                                        qty =int(input("Enter Quantity of item in (1,2,3...)as per your requirement: "))
                                                except ValueError:
                                                        print("Please Enter Numbers Only!")
                                                else:
                                                        qty
                                                        break        
                                        #qty =int(input("Enter Quantity of item in (1,2,3...)as per your requirement: "))
                                        Usermgmt.Order_Items(id, qty)

                                elif(choice == 7):
                                                        #type = input("Enter type of item Veg/Non-Veg: ")
                                                        while 1:
                                                                try:
                                                                        type = input("Enter Type of Item(['*': for Veg]/['#': Non-veg]): ")
                                                                        if (type == "*" or type == "#" ):
                                                                                type
                                                                                break
                                                                        else:
                                                                                raise TypeError
                                                                except TypeError:
                                                                        print("Please Enter Valid Input!")
                                                        Usermgmt. Search_Menu_bytype(type)


                                elif(choice == 3):
                                    Usermgmt.Display_Order()

                                elif(choice == 4):
                                        Usermgmt.Display_Order()
                                        while 1:
                                                try:
                                                        id = int(input("Enter Id Of Item to update: "))
                                                        if(len(str(id)) == 3):
                                                                id
                                                        else:
                                                                raise ValueError
                                                except ValueError:
                                                        print("Please Enter Numbers and Of 3 digit!")
                                                else:
                                                        id
                                                        break        
                                        #id = int(input("Enter Id Of Item to update: "))
                                        Usermgmt.UpdateItembyId(id)

                                elif(choice == 5):
                                        Usermgmt.Display_Order()
                                        while 1:
                                                try:
                                                        id = int(input("Enter Id Of Item to Delete: "))
                                                        if(len(str(id)) == 3):
                                                                id
                                                        else:
                                                                raise ValueError
                                                except ValueError:
                                                        print("Please Enter Numbers and Of 3 digit!")
                                                else:
                                                        id
                                                        break        
                                        #id = int(input("Enter Id Of Item to Delete: "))
                                        Usermgmt.DeleteItembyId(id) 

                                elif(choice == 6):
                                    Usermgmt.Bill_Format()
                                    Usermgmt.Display_Order()
                                    Usermgmt.GenerateBill()
                                    choice = 7
                                    break
                                    
                                                
                                                